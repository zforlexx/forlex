# Forlex Optimizer - build script (.NET Framework 4.8 + WPF, MSBuild 4.0)
# Usage:
#   .\build.ps1                -> builds Release into .\dist
#   .\build.ps1 -Run           -> builds and launches the app
#   .\build.ps1 -DebugBuild     -> builds Debug configuration
#   .\build.ps1 -Clean         -> removes obj/bin/dist before building
[CmdletBinding()]
param(
    [switch]$Run,
    [switch]$DebugBuild,
    [switch]$Clean,
    [switch]$NoBuild,
    [switch]$SkipSign,
    [switch]$LeadOnly
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$proj = Join-Path $root 'src\ForlexOptimizer.csproj'
$dist = Join-Path $root 'dist'
$config = if ($DebugBuild) { 'Debug' } else { 'Release' }

function Find-MSBuild {
    $candidates = @(
        'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\MSBuild.exe',
        'C:\Windows\Microsoft.NET\Framework\v4.0.30319\MSBuild.exe'
    )
    foreach ($c in $candidates) { if (Test-Path $c) { return $c } }
    $cmd = Get-Command MSBuild.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    throw 'No se encontro MSBuild.exe de .NET Framework 4.x.'
}

if ($Clean) {
    foreach ($d in @('src\obj', 'src\bin', $dist)) {
        $p = Join-Path $root $d
        if (Test-Path $p) { Remove-Item $p -Recurse -Force }
    }
    Write-Host 'Limpieza completa.' -ForegroundColor DarkGray
}

New-Item -ItemType Directory -Force -Path $dist | Out-Null

# Serialize concurrent builds (varios agentes pueden compilar a la vez).
$mutex = New-Object System.Threading.Mutex($false, 'Global\ForlexOptimizerBuild')
$locked = $mutex.WaitOne(180000)
try {
    # Si la app esta corriendo, se cierra para poder reemplazar el exe.
    # Ojo: en esta PC la app corre hospedada en powershell.exe (ver tools/run-app.ps1),
    # asi que tambien hay que cerrar esa ventana.
    Get-Process ForlexOptimizer -ErrorAction SilentlyContinue | Stop-Process -Force
    Get-Process powershell -ErrorAction SilentlyContinue |
        Where-Object { $_.MainWindowTitle -eq 'Forlex Optimizer' } |
        ForEach-Object { try { Stop-Process -Id $_.Id -Force } catch { } }
    Start-Sleep -Milliseconds 500
    if (-not $NoBuild) {
        $msbuild = Find-MSBuild
        $buildProj = $proj
        $args = @(
            $proj,
            "/t:Build",
            "/p:Configuration=$config",
            "/p:OutputPath=$dist\",
            "/p:IntermediateOutputPath=obj\$config\",
            '/nologo',
            '/v:minimal',
            '/clp:ErrorsOnly;Summary'
        )
        if ($LeadOnly) {
            # Proyecto auxiliar: solo shell + Core + Controls + Views/Core.
            # Sale a dist-lead para no pisar el build completo de los equipos.
            $buildProj = Join-Path $root 'tools\lead-check\LeadCheck.csproj'
            $outDir = Join-Path $root 'dist-lead'
            New-Item -ItemType Directory -Force -Path $outDir | Out-Null
            $args = @(
                $buildProj,
                "/t:Build",
                "/p:Configuration=$config",
                "/p:OutputPath=$outDir\",
                "/p:IntermediateOutputPath=$(Join-Path $root 'tools\lead-check\obj\')\",
                '/nologo',
                '/v:minimal',
                '/clp:ErrorsOnly;Summary'
            )
        }
        Write-Host "Compilando Forlex Optimizer ($config)..." -ForegroundColor Cyan
        # Reintentos: el antivirus/SAC a veces mantiene bloqueado el exe de dist unos
        # segundos al reemplazarlo (MSB3021/MSB3027). Se reintenta sin abortar.
        $attempt = 0
        while ($true) {
            $attempt++
            $out = & $msbuild @args 2>&1
            $out | Select-Object -Last 40 | ForEach-Object { Write-Host $_ }
            if ($LASTEXITCODE -eq 0) { break }
            $text = ($out | Out-String)
            if ($attempt -lt 4 -and ($text -match 'MSB3021|MSB3027|siendo utilizado en otro proceso')) {
                Write-Host "Archivo bloqueado al copiar (intento $attempt). Reintentando en 20 s..." -ForegroundColor Yellow
                Start-Sleep -Seconds 20
                Get-Process powershell -ErrorAction SilentlyContinue |
                    Where-Object { $_.MainWindowTitle -eq 'Forlex Optimizer' } |
                    ForEach-Object { try { Stop-Process -Id $_.Id -Force } catch { } }
                continue
            }
            throw "MSBuild fallo con codigo $LASTEXITCODE."
        }
        # Copiar solo el ejecutable y su .config si existe (todo lo demas va embebido).
        Get-ChildItem $(if ($LeadOnly) { Join-Path $root 'dist-lead' } else { $dist }) -Filter '*.pdb' -ErrorAction SilentlyContinue | Remove-Item -Force

        # Firma Authenticode: obligatoria en esta PC (Smart App Control / WDAC
        # bloquea los .exe locales sin firmar).
        $exePath = Join-Path $(if ($LeadOnly) { Join-Path $root 'dist-lead' } else { $dist }) 'ForlexOptimizer.exe'
        if (-not $SkipSign) {
            try {
                & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'tools\sign-file.ps1') -Path $exePath
            }
            catch { Write-Host ("Aviso: no se pudo firmar el exe: " + $_.Exception.Message) -ForegroundColor Yellow }
        }
        Write-Host ("Listo: " + $exePath) -ForegroundColor Green
    }
}
finally {
    if ($locked) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
}

if ($Run) {
    $exe = Join-Path $dist 'ForlexOptimizer.exe'
    if (-not (Test-Path $exe)) { throw "No existe $exe. Compila primero." }
    Start-Process -FilePath $exe
}
