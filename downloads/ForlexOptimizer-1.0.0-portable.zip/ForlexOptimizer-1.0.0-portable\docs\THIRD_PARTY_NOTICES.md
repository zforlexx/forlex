# Avisos de terceros (Third-party notices)

Forlex Optimizer es un proyecto propio. Parte del catálogo de datos (nombres, descripciones y
recetas de tweaks de Windows) y de las recetas PowerShell de arreglos/limpieza se derivaron de la
aplicación **CeitoTweaks** de ceitoooo, que se distribuye bajo licencia MIT. Esas recetas describen
configuraciones estándar y reversibles de Windows; la implementación de este proyecto (motor, UI,
servicios) es original.

## CeitoTweaks (MIT)

```
MIT License

Copyright (c) ceitoooo / CeitoTweaks

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Lucide (ISC)

Los iconos vectoriales de `src/Styles/Icons.xaml` se generaron a partir de [Lucide](https://lucide.dev),
licencia ISC:

```
ISC License

Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather
(MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.

Permission to use, copy, modify, and/or distribute this software for any purpose with or
without fee is hereby granted, provided that the above copyright notice and this permission
notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL
THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
OF THIS SOFTWARE.
```

## Microsoft .NET Framework / WPF

La aplicación usa .NET Framework 4.8 y WPF, componentes de Microsoft distribuidos con Windows.
El compilador Roslyn incluido en `tools/roslyn_pkg` es de Microsoft (licencia MIT).

## Otros

- El ícono de la aplicación es original (generado con Pillow para este proyecto).
- No se redistribuyen logos, música, sonidos, imágenes ni CSS de CeitoTweaks.
