# Inicia Forlex Optimizer.
#
# Esta PC tiene Smart App Control / WDAC activo: bloquea cualquier .exe nuevo sin
# reputacion, incluso firmado localmente. El host powershell.exe SI esta permitido,
# asi que cargamos la app como assembly en memoria dentro de un PowerShell firmado
# (-STA para WPF) y ejecutamos su Main. Requiere admin: si no lo hay, se relanza
# elevado (UAC).
param(
    [string]$Page = "",
    [string]$Dist = "dist",
    [switch]$Kill
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path | Split-Path -Parent
$exe = Join-Path (Join-Path $root $Dist) 'ForlexOptimizer.exe'
if (-not (Test-Path $exe)) { throw "No existe $exe. Ejecuta build.ps1 primero." }

if ($Kill) {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like '*run-app.ps1*' } |
        ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } catch { } }
    exit 0
}

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    $argList = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ('"' + $PSCommandPath + '"'))
    if ($Page -ne '') { $argList += @('-Page', $Page) }
    if ($Dist -ne 'dist') { $argList += @('-Dist', $Dist) }
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList ($argList -join ' ') -WindowStyle Hidden
    exit 0
}

# Ya somos admin: cargar la app en memoria y ejecutar su entry point.
$load = @'
$ErrorActionPreference = 'Stop'
$startPage = '__PAGE__'
if ($startPage -ne '') { $env:FORLEX_START_PAGE = $startPage }
$asmPath = '__EXE__'
$bytes = [System.IO.File]::ReadAllBytes($asmPath)
$asm = [System.Reflection.Assembly]::Load($bytes)
$entry = $asm.EntryPoint
if ($entry -eq $null) { throw 'El assembly no tiene punto de entrada.' }
$appArgs = [string[]]@(__ARGS__)
if ($entry.GetParameters().Length -eq 0) { $entry.Invoke($null, $null) }
else { $entry.Invoke($null, @(, $appArgs)) }
'@
$argLiteral = ''
if ($Page -ne '') { $argLiteral = "'--page', '" + $Page.Replace("'", "''") + "'" }
$load = $load.Replace('__EXE__', $exe.Replace("'", "''")).Replace('__ARGS__', $argLiteral).Replace('__PAGE__', $Page.Replace("'", "''"))
$encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($load))
& powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -EncodedCommand $encoded
