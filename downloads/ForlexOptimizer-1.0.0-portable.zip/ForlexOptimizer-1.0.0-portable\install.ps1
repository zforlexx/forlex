# Instala Forlex Optimizer de forma portable (carpeta de usuario + accesos directos).
# Uso:  powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
#       (pide elevacion solo para crear el acceso directo y confiar el certificado de firma)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $env:LOCALAPPDATA 'Programs\ForlexOptimizer'
$exe = Join-Path $root 'dist\ForlexOptimizer.exe'
if (-not (Test-Path $exe)) { throw "Falta $exe. Compila primero con build.ps1." }

Write-Host "Instalando en $target ..." -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $target | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $target 'tools') | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $target 'dist') | Out-Null

Copy-Item $exe (Join-Path $target 'dist\ForlexOptimizer.exe') -Force
Copy-Item (Join-Path $root 'tools\run-app.ps1') (Join-Path $target 'tools\run-app.ps1') -Force
Copy-Item (Join-Path $root 'ForlexOptimizer.cmd') (Join-Path $target 'ForlexOptimizer.cmd') -Force
Copy-Item (Join-Path $root 'README.md') (Join-Path $target 'README.md') -Force
Copy-Item (Join-Path $root 'LICENSE') (Join-Path $target 'LICENSE') -Force
if (Test-Path (Join-Path $root 'docs')) { Copy-Item (Join-Path $root 'docs') (Join-Path $target 'docs') -Recurse -Force }
if (Test-Path (Join-Path $root 'uninstall.ps1')) { Copy-Item (Join-Path $root 'uninstall.ps1') (Join-Path $target 'uninstall.ps1') -Force }

# Certificado de firma: si existe tools\signing\forlex-dev.cer, se confia a nivel usuario
# (asi el .exe queda con firma valida tambien en otras PCs donde se copie).
$cer = Join-Path $root 'tools\signing\forlex-dev.cer'
if (Test-Path $cer) {
    try {
        Import-Certificate -FilePath $cer -CertStoreLocation Cert:\CurrentUser\TrustedPublisher | Out-Null
        Write-Host 'Certificado de firma confiado en el usuario.' -ForegroundColor DarkGray
    } catch { }
}

$cmd = Join-Path $target 'ForlexOptimizer.cmd'
$shell = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath('Desktop')
$programs = [Environment]::GetFolderPath('Programs')

function New-Shortcut([string]$path) {
    $sc = $shell.CreateShortcut($path)
    $sc.TargetPath = $cmd
    $sc.WorkingDirectory = $target
    $sc.IconLocation = (Join-Path $target 'dist\ForlexOptimizer.exe') + ',0'
    $sc.Description = 'Forlex Optimizer'
    $sc.Save()
}
New-Shortcut (Join-Path $desktop 'Forlex Optimizer.lnk')
New-Shortcut (Join-Path $programs 'Forlex Optimizer.lnk')

Write-Host ''
Write-Host 'LISTO. Abre "Forlex Optimizer" desde el escritorio o el menu Inicio.' -ForegroundColor Green
Write-Host "Carpeta de datos: $env:LOCALAPPDATA\ForlexOptimizer"
Write-Host 'Para desinstalar: powershell -ExecutionPolicy Bypass -File uninstall.ps1'
