# Desinstala Forlex Optimizer (borra la carpeta instalada y los accesos directos).
# No borra tus backups ni ajustes salvo que pases -RemoveData.
param([switch]$RemoveData)
$ErrorActionPreference = 'Stop'
$target = Join-Path $env:LOCALAPPDATA 'Programs\ForlexOptimizer'
$data = Join-Path $env:LOCALAPPDATA 'ForlexOptimizer'
$shell = New-Object -ComObject WScript.Shell

Get-Process powershell -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -eq 'Forlex Optimizer' } |
    ForEach-Object { try { Stop-Process -Id $_.Id -Force } catch { } }

foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
    $lnk = Join-Path $dir 'Forlex Optimizer.lnk'
    if (Test-Path $lnk) { Remove-Item $lnk -Force; Write-Host "Borrado $lnk" -ForegroundColor DarkGray }
}
if (Test-Path $target) { Remove-Item $target -Recurse -Force; Write-Host "Borrado $target" -ForegroundColor DarkGray }
if ($RemoveData -and (Test-Path $data)) { Remove-Item $data -Recurse -Force; Write-Host "Borrados datos y backups en $data" -ForegroundColor Yellow }
Write-Host 'Forlex Optimizer desinstalado.' -ForegroundColor Green
