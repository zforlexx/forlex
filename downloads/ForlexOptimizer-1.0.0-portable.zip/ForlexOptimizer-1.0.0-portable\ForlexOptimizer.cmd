@echo off
rem Forlex Optimizer - lanzador. Requiere admin (pide UAC si hace falta).
rem La app se carga en memoria dentro de powershell.exe porque Smart App Control
rem bloquea ejecutables nuevos sin reputacion.
setlocal
set "ROOT=%~dp0"
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%ROOT%tools\run-app.ps1" %*
endlocal
