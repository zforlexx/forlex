# Catalogo de tweaks

Generado automaticamente por `tools/build_catalog.js`. Total: **393 tweaks** en **16 categorias**.

Riesgo: **Seguro** 275, **Moderado** 104, **Riesgoso** 14.

| Categoria | Tweaks | Subcategorias |
|---|---:|---|
| Rendimiento FPS | 28 | Esenciales, Latencia e input lag, Temporizadores, Avanzado, Interrupciones |
| Gráfica (GPU) | 19 | Optimizar gráfica, General, Avanzado, NVIDIA, Monitor y HDR |
| Red y WiFi | 42 | Latencia y ping, WiFi, Ethernet, DNS, Arreglos, Seguridad, Test |
| CPU y memoria | 20 | CPU, Memoria, Según tu RAM |
| Energía | 17 | Planes, Ajustes |
| Windows | 37 | Principal, Calidad de vida, Actualizaciones, Reloj, Personalización |
| Personalizar Windows | 37 | Barra de tareas, Menú Inicio, Escritorio y Explorador, Colores y tema, Ventanas, Arranque y extras |
| Segundo plano | 40 | Apps y procesos, Servicios, Opcionales |
| Privacidad | 42 | Telemetría, Datos y publicidad, Seguridad |
| Almacenamiento | 12 | - |
| Periféricos | 20 | Mouse y teclado, USB y audio, Mandos |
| BIOS y drivers | 5 | BIOS, Drivers |
| Priorizar juegos | 20 | Prioridad alta, Prioridad normal |
| Optimizar Apps | 12 | - |
| Accesos directos | 10 | - |
| Drivers de Mouse | 32 | OpenMouse, Logitech, Razer, SteelSeries, Corsair, HyperX, ASUS ROG, MSI, Glorious, Cooler Master, Redragon, Darmoshark, Pulsar Gaming Gears, Lamzu, ZOWIE, Vaxee, ATK, Attack Shark, Meetion, AULA, Scyrox, MCHOSE, Finalmouse, WLmouse, Fantech, Endgame Gear, Ninjutso, Mars Gaming, Cougar, Keychron, HP OMEN, Trust Gaming |

## Detalle por categoria

### Rendimiento FPS (28)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Activar Modo Juego | Esenciales | Seguro | Toggle | Si |
| Priorizar juegos sobre multimedia (MMCSS) | Esenciales | Seguro | Toggle | Si |
| Boost de prioridad para la app en primer plano | Esenciales | Seguro | Toggle | Si |
| Excluir carpetas de juegos del antivirus | Esenciales | Moderado | Accion | No |
| Ajustar Windows para "mejor rendimiento" (todos los efectos visuales) | Esenciales | Moderado | Toggle | Si |
| Desinstalar Xbox Game Bar | Esenciales | Moderado | Accion | No |
| Desactivar la grabación en segundo plano de la Game Bar | Esenciales | Seguro | Toggle | Si |
| Análisis del antivirus con poca CPU | Esenciales | Seguro | Toggle | Si |
| Desactivar Power Throttling | Esenciales | Moderado | Toggle | Si |
| Que Win+G y el botón Xbox no abran la Game Bar | Esenciales | Seguro | Toggle | Si |
| Que la Game Bar no muestre su panel al abrir juegos | Esenciales | Seguro | Toggle | Si |
| Aumentar FPS en tus juegos | Esenciales | Moderado | Accion | Si |
| Priorizar FPS | Esenciales | Moderado | Accion | Si |
| Prioridad alta de disco y sonido para juegos (MMCSS) | Latencia e input lag | Seguro | Toggle | Si |
| Reducir Input Lag | Latencia e input lag | Moderado | Accion | Si |
| Acelerar respuesta del sistema | Latencia e input lag | Moderado | Accion | Si |
| Desactivar Dynamic Tick (temporizador de CPU) | Temporizadores | Moderado | Toggle | Si |
| Desactivar HPET (temporizador de plataforma) | Temporizadores | Riesgoso | Toggle | Si |
| Temporizador de 0,5 ms siempre activo | Temporizadores | Moderado | Toggle | Si |
| Sincronización de reloj entre núcleos (TSC) | Temporizadores | Riesgoso | Toggle | Si |
| Resolución de temporizador global (Windows 11) | Temporizadores | Moderado | Toggle | Si |
| Ajustes de latencia del temporizador (BCD) | Temporizadores | Moderado | Accion | No |
| Desactivar mitigaciones de seguridad de CPU (Spectre/Meltdown) | Avanzado | Riesgoso | Toggle | Si |
| Desactivar Fault Tolerant Heap | Avanzado | Riesgoso | Toggle | Si |
| Desactivar VBS / Aislamiento del núcleo (Memory Integrity) | Avanzado | Riesgoso | Toggle | Si |
| Desactivar mitigaciones Spectre/Meltdown | Avanzado | Riesgoso | Toggle | Si |
| Desactivar el hipervisor de Windows (Hyper-V) | Avanzado | Riesgoso | Toggle | Si |
| Afinidad de interrupciones y modo MSI en dispositivos | Interrupciones | Moderado | Toggle | Si |

### Gráfica (GPU) (19)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Desactivar Ultra Low Power State (AMD) | Optimizar gráfica | Moderado | Toggle | Si |
| Activar programación de GPU acelerada por hardware | General | Moderado | Toggle | Si |
| Priorizar GPU para juegos | General | Seguro | Toggle | Si |
| Desactivar optimizaciones de pantalla completa | General | Moderado | Toggle | Si |
| Desactivar Xbox Game Bar / Game DVR | General | Seguro | Toggle | Si |
| Activar Hardware-Accelerated GPU Scheduling (HAGS) | General | Moderado | Toggle | Si |
| Limpiar caché de shaders (DirectX / NVIDIA) | General | Moderado | Accion | No |
| Usar siempre la placa de video dedicada | General | Moderado | Toggle | Si |
| Desactivar MPO (Multi-Plane Overlay) | General | Seguro | Toggle | Si |
| Optimizaciones para juegos en ventana | General | Moderado | Toggle | Si |
| Frecuencia variable (VRR) para juegos sin soporte | General | Seguro | Toggle | Si |
| Aumentar tiempo de espera de la GPU (TDR) | Avanzado | Moderado | Toggle | Si |
| Interrupciones MSI para la placa de video | Avanzado | Riesgoso | Toggle | Si |
| Desactivar telemetría de Nvidia | NVIDIA | Seguro | Toggle | Si |
| DPC por núcleo de CPU (NVIDIA) | NVIDIA | Moderado | Toggle | Si |
| Activar Auto HDR | Monitor y HDR | Moderado | Toggle | Si |
| Poner el monitor a su máxima frecuencia | Monitor y HDR | Seguro | Accion | No |
| Desactivar el brillo adaptativo | Monitor y HDR | Seguro | Toggle | Si |
| Abrir la configuración de HDR | Monitor y HDR | Seguro | Accion | No |

### Red y WiFi (42)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Desactivar Delivery Optimization | Latencia y ping | Seguro | Toggle | Si |
| Preferir IPv4 y desactivar Teredo | Latencia y ping | Moderado | Toggle | Si |
| Desactivar límite de red multimedia | Latencia y ping | Seguro | Toggle | Si |
| Desactivar algoritmo de Nagle | Latencia y ping | Moderado | Toggle | Si |
| Liberar ancho de banda reservado por QoS | Latencia y ping | Seguro | Toggle | Si |
| Ajustar parámetros TCP de Windows | Latencia y ping | Seguro | Toggle | Si |
| Reducir latencia de red (TCP ACK Frequency) | Latencia y ping | Moderado | Toggle | Si |
| Activar Receive Side Scaling (RSS) | Latencia y ping | Seguro | Toggle | Si |
| Prioridad de red para tus juegos (QoS) | Latencia y ping | Seguro | Toggle | Si |
| Más puertos de conexión y liberarlos antes | Latencia y ping | Seguro | Toggle | Si |
| Priorizar resolución de nombres de red | Latencia y ping | Seguro | Accion | Si |
| No compartir ni buscar redes WiFi sugeridas | WiFi | Seguro | Toggle | Si |
| WiFi sin ahorro de energía | WiFi | Seguro | Toggle | Si |
| Bajar la "agresividad de roaming" del WiFi | WiFi | Moderado | Toggle | Si |
| Preferir la banda de 5 GHz | WiFi | Moderado | Toggle | Si |
| No conectarse solo a hotspots abiertos | WiFi | Seguro | Toggle | Si |
| Forzar Ethernet a 1 Gbps Full Duplex | Ethernet | Riesgoso | Accion | No |
| Que Windows no apague la placa de red | Ethernet | Seguro | Toggle | Si |
| Desactivar Energy-Efficient Ethernet (EEE) | Ethernet | Seguro | Toggle | Si |
| Apagar el procesamiento diferido de la placa de red | Ethernet | Moderado | Toggle | Si |
| Desactivar la moderación de interrupciones | Ethernet | Moderado | Toggle | Si |
| Desactivar Large Send Offload (LSO) | Ethernet | Moderado | Toggle | Si |
| Desactivar Checksum Offload | Ethernet | Moderado | Toggle | Si |
| Cambiar DNS a Cloudflare (1.1.1.1) | DNS | Seguro | Accion | No |
| Cambiar DNS a Google (8.8.8.8) | DNS | Seguro | Accion | No |
| Volver al DNS automático (el de tu proveedor) | DNS | Seguro | Accion | No |
| Cambiar DNS a Quad9 (9.9.9.9) | DNS | Seguro | Accion | No |
| Cambiar DNS a AdGuard (bloquea publicidad) | DNS | Moderado | Accion | No |
| Cambiar DNS a Cloudflare Familia (1.1.1.2) | DNS | Seguro | Accion | No |
| DNS cifrado (DNS sobre HTTPS) automático | DNS | Seguro | Toggle | Si |
| Que un error de DNS no quede guardado | DNS | Seguro | Toggle | Si |
| Vaciar caché DNS y renovar la IP | Arreglos | Seguro | Accion | No |
| Desactivar SMB1 (protocolo viejo e inseguro) | Arreglos | Seguro | Toggle | Si |
| Reiniciar la pila de red de Windows | Arreglos | Moderado | Accion | No |
| Arreglar descargas lentas (auto-ajuste TCP) | Arreglos | Seguro | Toggle | Si |
| Desactivar LLMNR (resolución de nombres por la red local) | Arreglos | Seguro | Toggle | Si |
| Apagar el monitor de uso de datos (Ndu) | Arreglos | Moderado | Toggle | Si |
| Desactivar IPv6 en tus placas de red | Arreglos | Moderado | Toggle | Si |
| Desactivar túneles IPv6 viejos (ISATAP y 6to4) | Arreglos | Seguro | Toggle | Si |
| Apagar NetBIOS sobre TCP/IP | Seguridad | Seguro | Toggle | Si |
| No buscar proxy automático (WPAD) | Seguridad | Seguro | Toggle | Si |
| Test de velocidad | Test | Seguro | Accion | No |

### CPU y memoria (20)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Priorizar CPU para juegos | CPU | Seguro | Toggle | Si |
| Desactivar Core Parking de CPU | CPU | Moderado | Toggle | Si |
| No dejar que la CPU entre en reposo (C-States) | CPU | Riesgoso | Toggle | Si |
| Desactivar compresión de memoria | Memoria | Moderado | Toggle | Si |
| Mantener el kernel en RAM | Memoria | Riesgoso | Toggle | Si |
| Desactivar SysMain (Superfetch) | Memoria | Moderado | Toggle | Si |
| Desactivar Prefetch (solo con SSD) | Memoria | Moderado | Toggle | Si |
| Desactivar la combinación de páginas de memoria | Memoria | Moderado | Toggle | Si |
| Que Windows no precargue apps | Memoria | Seguro | Toggle | Si |
| Limpiador de RAM en espera (siempre activo) | Memoria | Seguro | Accion | No |
| Archivo de paginación estable | Memoria | Moderado | Toggle | Si |
| Desactivar la compresión de memoria | Memoria | Moderado | Toggle | Si |
| 4 GB de RAM | Según tu RAM | Seguro | Toggle | Si |
| 6 GB de RAM | Según tu RAM | Seguro | Toggle | Si |
| 8 GB de RAM | Según tu RAM | Seguro | Toggle | Si |
| 12 GB de RAM | Según tu RAM | Seguro | Toggle | Si |
| 16 GB de RAM | Según tu RAM | Seguro | Toggle | Si |
| 24 GB de RAM | Según tu RAM | Seguro | Toggle | Si |
| 32 GB de RAM | Según tu RAM | Seguro | Toggle | Si |
| 64 GB de RAM | Según tu RAM | Seguro | Toggle | Si |

### Energía (17)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Ceito Rendimiento | Planes | Moderado | Accion | No |
| Ceito Máximo Rendimiento | Planes | Moderado | Accion | No |
| Eliminar planes de energía predeterminados de Windows | Planes | Riesgoso | Accion | No |
| Activar plan de energía "Máximo rendimiento" oculto | Planes | Moderado | Accion | No |
| Ceito Notebook Gamer | Planes | Moderado | Accion | No |
| Ceito Silencioso | Planes | Moderado | Accion | No |
| Desactivar inicio rápido | Ajustes | Seguro | Toggle | Si |
| Desactivar hibernación | Ajustes | Moderado | Toggle | Si |
| Desactivar Sleep Study | Ajustes | Seguro | Toggle | Si |
| Volver a la suspensión clásica (S3) en vez de Modern Standby | Ajustes | Riesgoso | Toggle | Si |
| Que el disco no se apague solo | Ajustes | Seguro | Toggle | Si |
| PCI Express sin ahorro de energía (ASPM) | Ajustes | Moderado | Toggle | Si |
| No suspender mientras está enchufada | Ajustes | Seguro | Toggle | Si |
| Que la PC no se prenda sola | Ajustes | Seguro | Toggle | Si |
| Turbo del procesador agresivo | Ajustes | Moderado | Toggle | Si |
| Procesador siempre a máxima frecuencia | Ajustes | Moderado | Toggle | Si |
| Preferencia del procesador en rendimiento (EPP) | Ajustes | Moderado | Toggle | Si |

### Windows (37)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Desactivar todas las notificaciones | Principal | Moderado | Toggle | Si |
| Desactivar animaciones | Principal | Seguro | Toggle | Si |
| Desactivar efectos de transparencia | Principal | Seguro | Toggle | Si |
| Desactivar retraso de inicio de apps | Principal | Seguro | Toggle | Si |
| Desactivar Cortana | Principal | Seguro | Toggle | Si |
| Desactivar sugerencias de Windows | Principal | Seguro | Toggle | Si |
| Sin sugerencias ni publicidad en Configuración y pantalla de bloqueo | Principal | Seguro | Toggle | Si |
| Sin la pantalla "Terminá de configurar tu PC" | Principal | Seguro | Toggle | Si |
| Sin consejos en línea en Configuración | Principal | Seguro | Toggle | Si |
| Desactivar sonido de inicio | Calidad de vida | Seguro | Toggle | Si |
| Desactivar detección automática de tipo de carpeta | Calidad de vida | Moderado | Toggle | Si |
| Desactivar mantenimiento automático de Windows | Calidad de vida | Moderado | Toggle | Si |
| Habilitar rutas largas (Long Paths) | Calidad de vida | Seguro | Toggle | Si |
| Apagar la reproducción automática | Calidad de vida | Seguro | Toggle | Si |
| Apagar y reiniciar más rápido | Calidad de vida | Seguro | Toggle | Si |
| Pantalla azul con el detalle del error | Calidad de vida | Seguro | Toggle | Si |
| Sin teclas especiales al apretar Shift 5 veces | Calidad de vida | Seguro | Toggle | Si |
| Que Windows no reabra las apps al iniciar sesión | Calidad de vida | Seguro | Toggle | Si |
| Sin carpetas frecuentes en Acceso rápido | Calidad de vida | Seguro | Toggle | Si |
| Cada carpeta en un proceso aparte | Calidad de vida | Seguro | Toggle | Si |
| Sin el aviso "Tenés apps nuevas que pueden abrir esto" | Calidad de vida | Seguro | Toggle | Si |
| Que "Abrir con" no te mande a la Microsoft Store | Calidad de vida | Seguro | Toggle | Si |
| Sin el globo de "Poco espacio en disco" | Calidad de vida | Seguro | Toggle | Si |
| Que Edge no cree accesos directos en el escritorio | Calidad de vida | Seguro | Toggle | Si |
| Desactivar Windows Ink Workspace | Calidad de vida | Seguro | Toggle | Si |
| Restaurar Visor de fotos clásico | Calidad de vida | Moderado | Accion | Si |
| Pausar Windows Update por 7 días | Actualizaciones | Seguro | Accion | No |
| Que Windows Update no reinicie la PC con tu sesión abierta | Actualizaciones | Seguro | Toggle | Si |
| Horario activo amplio (de 8 a 2 de la mañana) | Actualizaciones | Seguro | Toggle | Si |
| Que Windows Update no te reemplace los drivers | Actualizaciones | Seguro | Toggle | Si |
| Postergar las actualizaciones grandes de Windows (1 año) | Actualizaciones | Moderado | Toggle | Si |
| Sincronizar la hora del sistema | Reloj | Seguro | Accion | No |
| Reloj del sistema en UTC | Reloj | Moderado | Toggle | Si |
| Accesos directos sin "- Acceso directo" | Personalización | Seguro | Toggle | Si |
| Vistas previas de la barra de tareas al instante | Personalización | Seguro | Toggle | Si |
| Sin "Ver escritorio" al pasar por la esquina | Personalización | Seguro | Toggle | Si |
| Desactivar Windows Spotlight | Personalización | Seguro | Toggle | Si |

### Personalizar Windows (37)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Alinear la barra de tareas a la izquierda | Barra de tareas | Seguro | Toggle | Si |
| Mostrar segundos en el reloj | Barra de tareas | Seguro | Toggle | Si |
| "Finalizar tarea" en la barra de tareas | Barra de tareas | Seguro | Toggle | Si |
| Buscador de la barra de tareas como ícono | Barra de tareas | Seguro | Toggle | Si |
| Ocultar el botón "Vista de tareas" | Barra de tareas | Seguro | Toggle | Si |
| Ocultar el buscador de la barra de tareas | Barra de tareas | Seguro | Toggle | Si |
| No agrupar las ventanas en la barra de tareas | Barra de tareas | Seguro | Toggle | Si |
| Íconos chicos en la barra de tareas (Windows 10) | Barra de tareas | Seguro | Toggle | Si |
| Ocultar la barra de tareas automáticamente | Barra de tareas | Seguro | Toggle | Si |
| Menú Inicio sin "Recomendado" ni apps sugeridas | Menú Inicio | Seguro | Toggle | Si |
| Más apps fijadas en el menú Inicio | Menú Inicio | Seguro | Toggle | Si |
| Mostrar siempre extensiones de archivo | Escritorio y Explorador | Seguro | Toggle | Si |
| Menú contextual clásico de Windows 10 | Escritorio y Explorador | Moderado | Toggle | Si |
| Mostrar archivos y carpetas ocultos | Escritorio y Explorador | Seguro | Toggle | Si |
| El Explorador abre en "Este equipo" | Escritorio y Explorador | Seguro | Toggle | Si |
| Explorador en vista compacta | Escritorio y Explorador | Seguro | Toggle | Si |
| Ocultar "Galería" en el Explorador | Escritorio y Explorador | Seguro | Toggle | Si |
| Mostrar "Este equipo" en el escritorio | Escritorio y Explorador | Seguro | Toggle | Si |
| Fondo de pantalla sin pérdida de calidad | Escritorio y Explorador | Seguro | Toggle | Si |
| Mostrar tu carpeta de usuario en el escritorio | Escritorio y Explorador | Seguro | Toggle | Si |
| Mostrar el Panel de control en el escritorio | Escritorio y Explorador | Seguro | Toggle | Si |
| Ruta completa en la ventana del Explorador | Escritorio y Explorador | Seguro | Toggle | Si |
| Casillas para seleccionar archivos | Escritorio y Explorador | Seguro | Toggle | Si |
| Sin publicidad de OneDrive en el Explorador | Escritorio y Explorador | Seguro | Toggle | Si |
| Forzar tema oscuro del sistema | Colores y tema | Seguro | Toggle | Si |
| Color de énfasis en las barras de título | Colores y tema | Seguro | Toggle | Si |
| Color de énfasis en el Inicio y la barra de tareas | Colores y tema | Seguro | Toggle | Si |
| Que sacudir una ventana no minimice las demás | Ventanas | Seguro | Toggle | Si |
| Sin el menú de diseños al pasar por el botón maximizar | Ventanas | Seguro | Toggle | Si |
| Acoplar ventanas sin sugerencias | Ventanas | Seguro | Toggle | Si |
| Alt + Tab solo con ventanas (sin pestañas de Edge) | Ventanas | Seguro | Toggle | Si |
| Instalar Rainmeter | Arranque y extras | Seguro | Accion | No |
| Skin de escritorio "Mond" | Arranque y extras | Seguro | Accion | No |
| Mensajes detallados de arranque y apagado | Arranque y extras | Seguro | Toggle | Si |
| Ir directo a la contraseña (sin pantalla de bloqueo) | Arranque y extras | Seguro | Toggle | Si |
| Reiniciar el Explorador | Arranque y extras | Seguro | Accion | No |
| Arranque más rápido (sin animaciones) | Arranque y extras | Moderado | Accion | No |

### Segundo plano (40)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Desactivar apps en segundo plano | Apps y procesos | Seguro | Toggle | Si |
| Desactivar inicio automático de OneDrive | Apps y procesos | Seguro | Toggle | Si |
| Eliminar apps preinstaladas innecesarias | Apps y procesos | Moderado | Accion | No |
| Cerrar procesos de fondo típicos de Windows 10/11 | Apps y procesos | Moderado | Accion | No |
| Desactivar Widgets de Windows 11 | Apps y procesos | Seguro | Toggle | Si |
| Desactivar ícono de Chat (Teams) en la barra de tareas | Apps y procesos | Seguro | Toggle | Si |
| Desactivar Windows Copilot | Apps y procesos | Seguro | Toggle | Si |
| Desactivar "Tu teléfono" / Phone Link | Apps y procesos | Seguro | Toggle | Si |
| Desactivar búsqueda web y Bing en el menú Inicio | Apps y procesos | Seguro | Toggle | Si |
| Que Microsoft Edge no quede abierto de fondo | Apps y procesos | Seguro | Toggle | Si |
| Que Google Chrome no quede abierto de fondo | Apps y procesos | Seguro | Toggle | Si |
| Que Teams y Copilot no arranquen con Windows | Apps y procesos | Seguro | Toggle | Si |
| Que la Store no actualice apps sola | Apps y procesos | Moderado | Toggle | Si |
| Desactivar indexado de búsqueda | Servicios | Moderado | Toggle | Si |
| Desactivar el servicio de Fax | Servicios | Seguro | Toggle | Si |
| Desactivar servicios de demostración y de pruebas de Microsoft | Servicios | Seguro | Toggle | Si |
| Desactivar el servicio de ubicación | Servicios | Moderado | Toggle | Si |
| Desactivar billetera y pagos NFC | Servicios | Seguro | Toggle | Si |
| Desactivar el servicio de control parental | Servicios | Seguro | Toggle | Si |
| Desactivar "Archivos sin conexión" | Servicios | Seguro | Toggle | Si |
| No guardar volcados de memoria en los pantallazos azules | Servicios | Moderado | Toggle | Si |
| Desactivar el Registro remoto | Servicios | Seguro | Toggle | Si |
| Desactivar el servicio de telefonía | Servicios | Seguro | Toggle | Si |
| Desactivar el servicio de Windows Insider | Servicios | Seguro | Toggle | Si |
| Desactivar los servicios de tarjetas inteligentes | Servicios | Seguro | Toggle | Si |
| Desactivar los servicios de invitado de Hyper-V | Servicios | Seguro | Toggle | Si |
| Desactivar el uso compartido de Windows Media Player | Servicios | Seguro | Toggle | Si |
| Desactivar el enrutamiento de mensajes WAP Push | Servicios | Seguro | Toggle | Si |
| Desactivar el recolector del Centro de diagnósticos | Servicios | Seguro | Toggle | Si |
| Desactivar los servicios de sensores | Servicios | Moderado | Toggle | Si |
| Desactivar el servicio biométrico | Servicios | Moderado | Toggle | Si |
| Desactivar las directivas de diagnóstico | Servicios | Moderado | Toggle | Si |
| Desactivar la Plataforma de dispositivos conectados | Servicios | Moderado | Toggle | Si |
| Desactivar más servicios de diagnóstico y telemetría | Servicios | Moderado | Accion | Si |
| Desactivar servicios poco usados | Servicios | Moderado | Accion | Si |
| Desactivar servicios de fondo poco usados | Servicios | Moderado | Accion | No |
| [Opcional] Desactivar servicios de Bluetooth | Opcionales | Moderado | Accion | Si |
| [Opcional] Desactivar administrador de mapas descargados | Opcionales | Moderado | Accion | Si |
| [Opcional] Desactivar servicios de impresión | Opcionales | Moderado | Accion | Si |
| [Opcional] Desactivar servicios de Xbox | Opcionales | Moderado | Accion | Si |

### Privacidad (42)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Desactivar telemetría | Telemetría | Seguro | Toggle | Si |
| Desactivar mejora de escritura y reconocimiento de voz | Telemetría | Seguro | Toggle | Si |
| Desactivar pedidos de feedback | Telemetría | Seguro | Toggle | Si |
| Desactivar servicio de telemetría (DiagTrack) | Telemetría | Seguro | Toggle | Si |
| Desactivar reporte de errores de Windows | Telemetría | Seguro | Toggle | Si |
| Desactivar tareas programadas de telemetría | Telemetría | Seguro | Toggle | Si |
| Desactivar el reconocimiento de voz en línea | Telemetría | Seguro | Toggle | Si |
| Edge sin telemetría ni sugerencias | Telemetría | Seguro | Toggle | Si |
| Office sin telemetría | Telemetría | Seguro | Toggle | Si |
| Desactivar el inventario de programas | Telemetría | Seguro | Toggle | Si |
| Desactivar la telemetría de compatibilidad | Telemetría | Seguro | Toggle | Si |
| Desactivar el Grabador de acciones | Telemetría | Seguro | Toggle | Si |
| Salir del Programa de mejora de la experiencia (CEIP) | Telemetría | Seguro | Toggle | Si |
| Activación sin validación en línea (AVS) | Telemetría | Seguro | Toggle | Si |
| No descargar modelos de voz en segundo plano | Telemetría | Seguro | Toggle | Si |
| Desactivar Cortana y Copilot | Datos y publicidad | Seguro | Toggle | Si |
| Desactivar historial de actividad | Datos y publicidad | Seguro | Toggle | Si |
| Desactivar rastreo de ubicación | Datos y publicidad | Seguro | Toggle | Si |
| Desactivar ID de publicidad | Datos y publicidad | Seguro | Toggle | Si |
| Que Windows no registre qué programas abrís | Datos y publicidad | Seguro | Toggle | Si |
| Sin "experiencias personalizadas" con tus datos | Datos y publicidad | Seguro | Toggle | Si |
| Sin contenido de Microsoft "en la nube" en tu escritorio | Datos y publicidad | Seguro | Toggle | Si |
| Que el buscador no guarde ni suba tu historial | Datos y publicidad | Seguro | Toggle | Si |
| Apagar Recall y "Click to Do" | Datos y publicidad | Seguro | Toggle | Si |
| No subir el portapapeles a la nube | Datos y publicidad | Seguro | Toggle | Si |
| Apagar las estadísticas de escritura | Datos y publicidad | Seguro | Toggle | Si |
| Sin archivos recientes en el Explorador | Datos y publicidad | Seguro | Toggle | Si |
| Desactivar "Buscar mi dispositivo" | Datos y publicidad | Moderado | Toggle | Si |
| Sin cámara en la pantalla de bloqueo | Datos y publicidad | Seguro | Toggle | Si |
| No compartir lo que escribís a mano | Datos y publicidad | Seguro | Toggle | Si |
| Que las apps no lean el diagnóstico de otras apps | Datos y publicidad | Seguro | Toggle | Si |
| Que las apps no vean tu nombre y foto de cuenta | Datos y publicidad | Seguro | Toggle | Si |
| Que las apps no se activen con tu voz | Datos y publicidad | Seguro | Toggle | Si |
| No subir tus mensajes de texto a la nube | Datos y publicidad | Seguro | Toggle | Si |
| No sincronizar tu configuración con la cuenta de Microsoft | Datos y publicidad | Seguro | Toggle | Si |
| Que los mapas no se actualicen solos | Datos y publicidad | Seguro | Toggle | Si |
| Que el DRM de Windows Media no se conecte a internet | Datos y publicidad | Seguro | Toggle | Si |
| Que OneDrive no use internet antes de que inicies sesión | Datos y publicidad | Seguro | Toggle | Si |
| Privacidad y sugerencias extra | Datos y publicidad | Seguro | Accion | Si |
| Bloquear enumeración anónima de cuentas (SAM) | Seguridad | Seguro | Toggle | Si |
| Desactivar Asistencia remota | Seguridad | Seguro | Toggle | Si |
| Desactivar WPBT | Seguridad | Riesgoso | Toggle | Si |

### Almacenamiento (12)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Desactivar Storage Sense | - | Seguro | Toggle | Si |
| Desactivar registro de último acceso | - | Seguro | Toggle | Si |
| Desactivar nombres cortos 8.3 en NTFS | - | Moderado | Toggle | Si |
| Desactivar Almacenamiento reservado | - | Moderado | Toggle | Si |
| No crear archivos Thumbs.db en carpetas de red | - | Seguro | Toggle | Si |
| Optimizar los SSD ahora (TRIM manual) | - | Seguro | Accion | No |
| Borrar componentes viejos de Windows Update | - | Seguro | Accion | No |
| Más memoria para el caché de archivos (NTFS) | - | Moderado | Toggle | Si |
| Asegurar que TRIM esté activado (SSD) | - | Seguro | Toggle | Si |
| Borrar la caché de Delivery Optimization | - | Seguro | Accion | No |
| Borrar descargas viejas de Windows Update | - | Seguro | Accion | No |
| Borrar los reportes de errores guardados | - | Seguro | Accion | No |

### Periféricos (20)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Desactivar mejorar precisión del puntero | Mouse y teclado | Seguro | Toggle | Si |
| Teclado sin delay | Mouse y teclado | Seguro | Toggle | Si |
| Cola de datos del mouse más chica | Mouse y teclado | Moderado | Toggle | Si |
| Cola de datos del teclado más chica | Mouse y teclado | Moderado | Toggle | Si |
| Menús y avisos al instante al pasar el mouse | Mouse y teclado | Seguro | Toggle | Si |
| Sin Teclas filtro ni Teclas de alternancia | Mouse y teclado | Seguro | Toggle | Si |
| Bloq Num prendido al iniciar Windows | Mouse y teclado | Seguro | Toggle | Si |
| Que el mouse no despierte la PC | Mouse y teclado | Seguro | Toggle | Si |
| Que Alt + Shift no cambie el idioma del teclado | Mouse y teclado | Seguro | Toggle | Si |
| Velocidad del puntero en 6/11 (1:1 exacto) | Mouse y teclado | Seguro | Accion | No |
| Curva de mouse lineal (sin aceleración) | Mouse y teclado | Moderado | Accion | Si |
| Desactivar ahorro de energía de USB | USB y audio | Seguro | Toggle | Si |
| Desactivar ahorro de energía en dispositivos | USB y audio | Moderado | Toggle | Si |
| USB 3 sin ahorro de energía del enlace | USB y audio | Seguro | Toggle | Si |
| Que Windows no baje el volumen en llamadas | USB y audio | Seguro | Toggle | Si |
| Silenciar los sonidos del sistema | USB y audio | Seguro | Toggle | Si |
| Arreglar el volumen bajo de auriculares Bluetooth | USB y audio | Moderado | Toggle | Si |
| Desactivar las mejoras de audio de Windows | USB y audio | Moderado | Toggle | Si |
| Que Windows no apague el Bluetooth para ahorrar energía | USB y audio | Seguro | Toggle | Si |
| El botón Xbox del mando no abre nada | Mandos | Seguro | Toggle | Si |

### BIOS y drivers (5)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Reiniciar directo a la BIOS | BIOS | Moderado | Accion | No |
| Diagnóstico de BIOS y hardware | BIOS | Seguro | Accion | No |
| Descargar drivers de NVIDIA | Drivers | Seguro | Accion | No |
| Descargar drivers de AMD | Drivers | Seguro | Accion | No |
| Descargar drivers de Intel | Drivers | Seguro | Accion | No |

### Priorizar juegos (20)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Prioridad alta de CPU para Roblox | Prioridad alta | Seguro | Toggle | Si |
| Prioridad alta de CPU para Fortnite | Prioridad alta | Seguro | Toggle | Si |
| Prioridad alta de CPU para CS2 | Prioridad alta | Seguro | Toggle | Si |
| Prioridad alta de CPU para League of Legends | Prioridad alta | Seguro | Toggle | Si |
| Prioridad alta de CPU para Minecraft (Java) | Prioridad alta | Moderado | Toggle | Si |
| Prioridad alta de CPU para Valorant | Prioridad alta | Seguro | Toggle | Si |
| Prioridad alta de CPU para Apex Legends | Prioridad alta | Seguro | Toggle | Si |
| Prioridad alta de CPU para Call of Duty / Warzone | Prioridad alta | Seguro | Toggle | Si |
| Prioridad alta de CPU para GTA V | Prioridad alta | Seguro | Toggle | Si |
| Prioridad alta de CPU para Rocket League | Prioridad alta | Seguro | Toggle | Si |
| Volver a prioridad normal — Roblox | Prioridad normal | Seguro | Accion | No |
| Volver a prioridad normal — Fortnite | Prioridad normal | Seguro | Accion | No |
| Volver a prioridad normal — CS2 | Prioridad normal | Seguro | Accion | No |
| Volver a prioridad normal — League of Legends | Prioridad normal | Seguro | Accion | No |
| Volver a prioridad normal — Minecraft (Java) | Prioridad normal | Seguro | Accion | No |
| Volver a prioridad normal — Valorant | Prioridad normal | Seguro | Accion | No |
| Volver a prioridad normal — Apex Legends | Prioridad normal | Seguro | Accion | No |
| Volver a prioridad normal — Call of Duty / Warzone | Prioridad normal | Seguro | Accion | No |
| Volver a prioridad normal — GTA V | Prioridad normal | Seguro | Accion | No |
| Volver a prioridad normal — Rocket League | Prioridad normal | Seguro | Accion | No |

### Optimizar Apps (12)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Optimizar Spotify | - | Moderado | Accion | No |
| Optimizar Discord | - | Moderado | Accion | No |
| Optimizar Chrome | - | Moderado | Accion | No |
| Optimizar Edge | - | Moderado | Accion | No |
| Optimizar Brave | - | Moderado | Accion | No |
| Optimizar Opera GX | - | Moderado | Accion | No |
| Optimizar OBS Studio | - | Moderado | Accion | No |
| Optimizar Medal | - | Moderado | Accion | No |
| Optimizar Adobe Creative Cloud | - | Moderado | Accion | No |
| Optimizar Steam (más FPS en tus juegos) | - | Moderado | Accion | No |
| Optimizar SteelSeries GG y Sonar | - | Moderado | Accion | No |
| Optimizar TikTok LIVE Studio (Full Rendimiento) | - | Moderado | Accion | No |

### Accesos directos (10)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| Preferencia de GPU por app | - | Seguro | Accion | No |
| Multitareas | - | Seguro | Accion | No |
| Asistente de Enfoque | - | Seguro | Accion | No |
| Efectos de transparencia | - | Seguro | Accion | No |
| Modo Tablet | - | Seguro | Accion | No |
| Privacidad | - | Seguro | Accion | No |
| Programas de inicio | - | Seguro | Accion | No |
| Restablecer esta PC de fábrica | - | Moderado | Accion | No |
| Opciones de rendimiento | - | Seguro | Accion | No |
| Diagnóstico de memoria de Windows | - | Moderado | Accion | No |

### Drivers de Mouse (32)

| Tweak | Subcategoria | Riesgo | Accion | Revierte |
|---|---|---|---|---|
| OpenMouse | OpenMouse | Seguro | Accion | No |
| Logitech | Logitech | Seguro | Accion | No |
| Razer | Razer | Seguro | Accion | No |
| SteelSeries | SteelSeries | Seguro | Accion | No |
| Corsair | Corsair | Seguro | Accion | No |
| HyperX | HyperX | Seguro | Accion | No |
| ASUS ROG | ASUS ROG | Seguro | Accion | No |
| MSI | MSI | Seguro | Accion | No |
| Glorious | Glorious | Seguro | Accion | No |
| Cooler Master | Cooler Master | Seguro | Accion | No |
| Redragon | Redragon | Seguro | Accion | No |
| Darmoshark | Darmoshark | Seguro | Accion | No |
| Pulsar Gaming Gears | Pulsar Gaming Gears | Seguro | Accion | No |
| Lamzu | Lamzu | Seguro | Accion | No |
| ZOWIE | ZOWIE | Seguro | Accion | No |
| Vaxee | Vaxee | Seguro | Accion | No |
| ATK | ATK | Seguro | Accion | No |
| Attack Shark | Attack Shark | Seguro | Accion | No |
| Meetion | Meetion | Seguro | Accion | No |
| AULA | AULA | Seguro | Accion | No |
| Scyrox | Scyrox | Seguro | Accion | No |
| MCHOSE | MCHOSE | Seguro | Accion | No |
| Finalmouse | Finalmouse | Seguro | Accion | No |
| WLmouse | WLmouse | Seguro | Accion | No |
| Fantech | Fantech | Seguro | Accion | No |
| Endgame Gear | Endgame Gear | Seguro | Accion | No |
| Ninjutso | Ninjutso | Seguro | Accion | No |
| Mars Gaming | Mars Gaming | Seguro | Accion | No |
| Cougar | Cougar | Seguro | Accion | No |
| Keychron | Keychron | Seguro | Accion | No |
| HP OMEN | HP OMEN | Seguro | Accion | No |
| Trust Gaming | Trust Gaming | Seguro | Accion | No |
