# Forlex Optimizer — contrato de trabajo del equipo

App de optimizacion de Windows **propia** (marca Forlex), escrita en **C# 7.3 + WPF sobre .NET Framework 4.8**,
compilada con **MSBuild 4.0** y el compilador **Roslyn** incluido en `tools/roslyn_pkg`. Interfaz 100% en espanol.
Todo el trabajo vive en `C:\Users\hp14\Documents\proyectos\forlex-optimizer`.

## 1. Como compilar y ver

Este shell tiene la ExecutionPolicy en Restricted, asi que los `.ps1` se ejecutan con un PowerShell hijo:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "C:\Users\hp14\Documents\proyectos\forlex-optimizer\build.ps1"
```

- Compila `Release` a `dist\ForlexOptimizer.exe` (mata automaticamente la app si estaba abierta; no la dejes corriendo).
- Para ver una pagina concreta: `powershell -NoProfile -ExecutionPolicy Bypass -File tools\dev-screenshot.ps1 -Name mipagina -Page tweaks`
  - `-Page` acepta los keys de navegacion (`dashboard`, `tweaks`, `optimizeall`, `gpu`, `powerplan`, `backups`, `gamemode`,
    `diagnose`, `tests`, `system`, `fixes`, `cleaner`, `programs`, `startup`, `games`, `customize`, `profile`, `assistant`, `settings`, `about`).
  - Guarda la captura en `_shots\<nombre>.png`. Usa la herramienta `read_image` para revisarla.
- Los logs de la app estan en `%LOCALAPPDATA%\ForlexOptimizer\logs\forlex-*.log`.
- El build tarda ~5-20 s. **Nunca edites `ForlexOptimizer.csproj`** (los `*.cs` y `*.xaml` se incluyen por wildcard).

## 2. Estructura y propiedad de archivos

```
src/
  App.xaml(.cs), MainWindow.xaml(.cs)   -> Lead
  Core/                                  -> Lead (API compartida)
  Controls/                              -> Lead
  Styles/Theme.xaml, Controls.xaml, Icons.xaml -> Lead
  Views/Core/                            -> Lead
  Views/Tweaks/       + Services/Tweaks/       -> ui-tweaks
  Views/System/       + Services/SystemTools/  -> ui-system
  Views/Diagnostics/  + Services/Diagnostics/  -> ui-diagnostics
  Views/Games/        + Services/Games/        -> ui-games
  Views/Custom/       + Services/Custom/, i18n/ -> ui-custom
data/tweaks.json      -> Lead (catalogo generado)
tools/                -> Lead
```

**No toques archivos fuera de tus carpetas.** Si necesitas un cambio en `Core`, `MainWindow` o los estilos,
mandale un mensaje al Lead con la firma exacta que necesitas. No agregues dependencias NuGet ni referencias
nuevas al proyecto.

## 3. Contrato de una pagina

Cada pagina es un `UserControl` WPF compilado (XAML + code-behind) que hereda de `PageBase`:

```xml
<UserControl x:Class="ForlexOptimizer.Views.Tweaks.TweaksPage"
             xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
             xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
             Background="Transparent">
    <ScrollViewer VerticalScrollBarVisibility="Auto">
        <StackPanel Margin="28,24,28,28"> <!-- contenido --> </StackPanel>
    </ScrollViewer>
</UserControl>
```

```csharp
namespace ForlexOptimizer.Views.Tweaks
{
    public partial class TweaksPage : PageBase
    {
        public TweaksPage() { InitializeComponent(); }
        public override void OnNavigatedTo() { /* refrescar datos */ }
    }
}
```

- Constructor **sin parametros** obligatorio. `Navigation.CreatePage` resuelve `ForlexOptimizer.Views.<TypeName>`.
- La pagina se cachea: `OnNavigatedTo()` se llama cada vez que se entra; ahi refresca datos.
- `OnNavigatedFrom()` para detener timers/procesos.
- Navegar a otra pagina: `Navigate("gpu")` (de `PageBase`) o `MainWindow.Current.NavigateTo("gpu")`.
- Avisos: `Toast("...")`, `ToastSuccess(...)`, `ToastError(...)`.
- El shell ya pone el titulo/subtitulo de la pagina en el header: no repitas un H1 gigante; empeza con el contenido
  (a lo sumo un H2/kicker dentro del contenido).
- Toda operacion larga: `async` + `await`, sin bloquear la UI. Actualiza controles via `Ui.RunOnUi(...)` si venis de un thread
  de fondo. Maneja errores con try/catch y `ToastError`.
- Rendimiento: listas grandes (`ItemsControl`/`ListBox`) con virtualizacion
  (`VirtualizingStackPanel.IsVirtualizing="True"` y `ScrollViewer.CanContentScroll="True"`).

## 4. Sistema de diseno (usar SIEMPRE estas claves)

Colores/brushes (DynamicResource): `BgBrush`, `BgElevatedBrush`, `BgSoftBrush`, `CardBrush`, `CardHoverBrush`,
`BorderBrush`, `BorderStrongBrush`, `TextBrush`, `TextSecondaryBrush`, `TextMutedBrush`, `AccentBrush`, `Accent2Brush`,
`AccentSoftBrush`, `SuccessBrush`, `WarningBrush`, `DangerBrush`, `SuccessSoftBrush`, `WarningSoftBrush`,
`DangerSoftBrush`, `AccentGradientBrush`, `HeroGradientBrush`, `GlowBrush`, `OverlayBrush`, `WhiteBrush`.

Estilos de texto: `H1`, `H2`, `H3`, `H4`, `Body`, `Secondary`, `Muted`, `Caption`, `Kicker`, `Mono`, `Icon`.
Contenedores: `Card` (Border, padding 20), `CardFlat`, `CardClickable`, `Panel`, `PillBorder`, `Divider`.
Botones: `PrimaryButton`, `SecondaryButton`, `GhostButton`, `DangerButton`, `SuccessButton`, `IconButton`,
`ChipButton`, `WindowButton`.
Controles: `InputBox` (TextBox), `ToggleSwitch` (CheckBox), `FilterChip` (RadioButton), `AppComboBox` (ComboBox),
`ThinProgress` (ProgressBar), `BadgeSafe`/`BadgeModerate`/`BadgeRisky` + `BadgeText` (Border/TextBlock).
Fuentes: `AppFont`, `TextFont`, `MonoFont` (usa los estilos; no inventes font-family).

Iconos: son geometrias vectoriales Lucide generadas en `Styles/Icons.xaml`.
En XAML: `<Path Style="{StaticResource IconPath}" Data="{StaticResource IconGamepad2}" />`
(kebab-case -> PascalCase con prefijo Icon; ej. `zap` -> `IconZap`, `gamepad-2` -> `IconGamepad2`).
En C#: `IconHelper.Get("zap")`. Nombres utiles: house, sliders-horizontal, zap, monitor-cog, battery-charging,
history, gamepad-2, stethoscope, flask-conical, cpu, wrench, sparkles, download, power, target, palette, user,
settings, info, search, shield-check, thermometer, gauge, activity, monitor, mouse, keyboard, crosshair, timer,
hard-drive, network, wifi, trash-2, refresh-cw, rotate-ccw, check, x, alert-triangle, triangle-alert, circle-check,
circle-alert, chevron-right, arrow-right, arrow-up-right, play, pause, plus, minus, copy, clipboard, terminal,
package, rocket, trophy, star, flame, mic, volume-2, image, filter, layers, database, globe, link, external-link.

**Nunca** uses glifos de fuentes tipo Segoe MDL2: solo el sistema de iconos de arriba.

## 5. APIs del nucleo (no modificar, solo usar)

```csharp
// Catalogo
Catalog.Instance.Tweaks            // List<TweakDef>
Catalog.Instance.Categories        // List<CategoryInfo> {Name, Icon, Description, Subcategories, Count}
Catalog.Instance.TotalCount
Catalog.Instance.Get("tweak-id")   // TweakDef o null
Catalog.Instance.Search(query, category, risk, onlyApplied, onlyPending)
Catalog.Instance.InCategory("Red y WiFi")

// TweakDef: Id, Name, Category, Subcategory, Description, Warning, Risk ("seguro"|"moderado"|"riesgoso"),
//   ActionOnly, ButtonLabel, Premium, RequiresRestart, LaptopWarning, Recommended, Tags, Special

// Estado persistido
AppState.Instance.Settings          // AppSettings (Language, Theme, Accent, UserName, MinimizeToTray, ...)
AppState.Instance.Applied          // List<AppliedTweak> {Id, Name, Category, AppliedAt, BackupId}
AppState.Instance.IsApplied(id); AppState.Instance.SaveSettings();

// Motor
await TweakEngine.ApplyAsync(tweak)        // TweakResult {Ok, Message, Detail, BackupId}
await TweakEngine.RevertAsync(tweak)
await TweakEngine.ApplyManyAsync(coleccion, progress)
await TweakEngine.RevertAllAsync(progress) // int revertidos
TweakEngine.Progress += (msg) => ...; TweakEngine.TweakChanged += (tweak, aplicado) => ...;
await RestorePointService.CreateAsync("descripcion")   // ProcessResult

// Sistema
LiveMonitor.Instance.Start();  // Current: LiveStats {Cpu, Gpu, RamPercent, RamUsedGb, RamTotalGb, DiskPercent, ...}
LiveMonitor.Instance.Updated += (stats) => ...;   CpuHistory/RamHistory/GpuHistory (List<double>)
await SystemInfoService.CollectAsync();  // SystemSnapshot {CpuName, GpuName, GpuVendor, RamTotalGb, ...}
await PowerPlanService.ListAsync(); await PowerPlanService.ActivateAsync(guid);
List<PowerPlanInfo> {Guid, Name, Active}; PowerPlanService.CreateForlexPlanAsync("rendimiento"|"notebook"|"silent");

// Ejecucion
await PowerShellRunner.RunScriptAsync(script, timeoutMs)  // ProcessResult {Ok, Output, ExitCode}
await PowerShellRunner.RunCommandAsync("powercfg.exe", new List<string>{"-list"})
PowerShellRunner.OpenUrl(url); PowerShellRunner.OpenPath(path); PowerShellRunner.RunAndForget(exe);

// UI / varios
Ui.Toast(...), Ui.ConfirmAsync(titulo, mensaje, ok, cancelar, danger), Ui.Alert(...), Ui.FormatBytes(x),
Ui.CopyText(x), Ui.OpenFolder(path), Ui.RiskText(risk), Ui.RiskBrush(risk), Ui.RiskSoftBrush(risk), Ui.RunOnUi(...)
I18n.T("clave", "texto por defecto");  I18n.TweakName(tweak); I18n.TweakDescription(tweak); I18n.Risk(risk)
ThemeService.Apply("dark"|"oled"|"midnight"|"crimson"|"light", "#7C5CFF");
Log.Info/Warn/Error; Storage.AppDataDir; Storage.WriteJson(ruta, obj); Storage.ReadJson<T>(ruta);
await PowerShellRunner.RunCommandAsync(...); RegistryUtil.SetValue(path,name,kind,value); RegistryUtil.ReadValue(...)
```

Controles propios: `ForlexOptimizer.Controls.LiveChart` (sparkline: `SetValues(IList<double>)`, `Push(double)`,
props `LineBrush`, `FillBrush`, `MaxValue`, `AutoScale`, `ShowGrid`) y `RingProgress` (`Value` 0-100, `CenterText`,
`Caption`, `ProgressBrush`, `TrackBrush`, `Thickness`). En XAML agregar
`xmlns:ctrl="clr-namespace:ForlexOptimizer.Controls"`.

## 6. Calidad y estilo visual

- Fondo transparente en la pagina; todo el contenido dentro de tarjetas/paneles sobre el fondo del shell.
- Espaciados: margen exterior 26-32 px, gap entre tarjetas 14-18 px, padding de tarjeta 18-22 px.
- Titulos de seccion con `H2`/`H3`; textos secundarios con `Secondary`/`Muted`; numeros grandes con `H1` y `Mono` para datos.
- Estados vacios utiles (icono + texto + boton), nunca una pantalla en blanco.
- Botones con acciones destructivas en `DangerButton` y confirmacion con `Ui.ConfirmAsync`.
- Nada de texto en ingles en la UI. Acentos y enie correctos.
- Las capturas deben verse modernas, oscuras, con acentos violeta/cyan y buen contraste.

## 7. Material de referencia (comportamiento)

La app original (MIT) esta extraida en `C:\Users\hp14\Documents\proyectos\_ceito_recon\asar_unpacked\`:

- `tweaks/*.js`: implementaciones reales de tweaks, fixes, programas, GPU, planes, limpieza, etc. (PowerShell embebido).
- `renderer/*.js`, `renderer/index.html`, `renderer/*.css`: pantallas y funciones de la app original (referencia de features).
- `tweaks/tweakI18n*.js`: traducciones por id de tweak.

Podes **leer** todo eso para replicar comportamiento y nombres, pero **escribi codigo C#/XAML propio**.
No copies logos, sonidos, musica, imagenes ni CSS de la app original. El catalogo de datos lo genera el Lead.

## 8. Flujo de trabajo

1. Lee esta guia. 2. Toma tu tarea del tablero compartido (`team_task_list`) y marcala `in_progress` (claim con revision).
3. Implementa **archivo por archivo** y compila seguido; los errores de compilacion son tuyos, arreglalos.
4. Antes de terminar cada pagina: build OK + screenshot revisada + sin excepciones en el log.
5. Marca la tarea `completed` y manda un mensaje corto al Lead (que hiciste, paginas, screenshot, pendientes).
6. Si te bloquea algo del Lead (API faltante, datos), avisale y segui con otra parte de tu alcance.

Todo el equipo comparte el mismo filesystem: no borres archivos ajenos y no renombres APIs compartidas.
