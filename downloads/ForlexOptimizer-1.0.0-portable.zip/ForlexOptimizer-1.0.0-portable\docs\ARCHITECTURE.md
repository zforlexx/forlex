# Arquitectura de Forlex Optimizer

App de escritorio Windows en **C# 7.3 + WPF sobre .NET Framework 4.8**, compilada con **MSBuild 4.0** y el
compilador **Roslyn** incluido en `tools/roslyn_pkg` (no requiere SDK de .NET). Un solo proceso, sin
servidores ni dependencias externas en runtime.

## Capas

```
┌──────────────────────────────────────────────────────────────────┐
│ Shell (MainWindow): sidebar, header, toasts, navegación por cache │
├──────────────────────────────────────────────────────────────────┤
│ Vistas (WPF UserControls que heredan PageBase)                    │
│  Views/Core · Tweaks · System · Diagnostics · Games · Custom      │
├──────────────────────────────────────────────────────────────────┤
│ Servicios por dominio (Services/*)                                │
├──────────────────────────────────────────────────────────────────┤
│ Core: catálogo, motor de tweaks, backups, registro, estado, tema  │
│       PowerShell runner, monitor en vivo, info de sistema, i18n   │
├──────────────────────────────────────────────────────────────────┤
│ Windows: registro, servicios, powercfg, WMI, P/Invoke, PowerShell │
└──────────────────────────────────────────────────────────────────┘
```

## Núcleo

- **`Core/Catalog.cs`** carga `data/tweaks.json` embebido (393 tweaks, 16 categorías) y expone búsqueda,
  filtros y agrupación. El JSON lo genera `tools/build_catalog.js` a partir de la app de referencia MIT
  (ver THIRD_PARTY_NOTICES).
- **`Core/Models.cs`** define `TweakDef` (metadatos + `Apply`/`Revert`/`Backups`) y `TweakOp` con los tipos
  de operación: `regSet`, `regDel`, `script` (PowerShell), `cmd`, `raw`, `regImport` (.reg embebido),
  `powImport` (planes de energía), `powersharing`, `openUrl`, `openApp`, `audioRefresh`, `navigate`, `purge`,
  `timer`.
- **`Core/TweakEngine.cs`** aplica operaciones en orden, guarda un **snapshot exacto** de cada valor de
  registro antes de escribirlo (`BackupRecord` en `%LOCALAPPDATA%\ForlexOptimizer\backups`), marca el estado
  en `state.json` y al revertir ejecuta el revert + restaura los snapshots (el snapshot gana). También expone
  `ApplyManyAsync` / `RevertAllAsync` con progreso y eventos para la UI.
- **`Core/RegistryUtil.cs`** normaliza rutas (`HKLM:\...`), hace snapshots de tipo/valor y restaura valores
  `String`, `DWord`, `QWord`, `Binary`, `MultiString` y `ExpandString`.
- **`Core/PowerShellRunner.cs`** ejecuta scripts con PowerShell 5.1 (`-NoProfile -ExecutionPolicy Bypass`),
  escribe los `.ps1` en UTF-8 con BOM, captura stdout/stderr con timeout y nunca deja procesos colgados.
- **`Core/LiveMonitor.cs`** muestrea CPU/RAM/GPU/disco con PerformanceCounters y P/Invoke, con historial
  para los gráficos. Incluye helpers de purga de standby list y resolución de timer.
- **`Core/AppState.cs`** persiste ajustes, tweaks aplicados y backups en JSON atómico.
- **`Core/ThemeService.cs` / `Styles/*.xaml`** sistema de diseño con 5 paletas y color de acento en vivo.
  Los iconos son geometrías Lucide (`Styles/Icons.xaml`, 1746 iconos, ISC) generadas por
  `tools/make_icons.js`.

## UI

- `MainWindow` construye la navegación desde `Core/PageBase.cs` (clase `Navigation`), resuelve las páginas
  por reflexión (`ForlexOptimizer.Views.<TypeName>`) y las cachea. Si un módulo falta, muestra un
  placeholder en vez de romper.
- Todas las páginas heredan de `PageBase` (`OnNavigatedTo`/`OnNavigatedFrom`), usan estilos compartidos y
  `Ui.Toast/Confirm` para feedback.
- Cada módulo puede tener servicios propios en `Services/<Dominio>`.

## Lanzamiento en PCs con Smart App Control

`tools/run-app.ps1` lee los bytes de `dist\ForlexOptimizer.exe`, los carga con `Assembly.Load` dentro de un
`powershell.exe -STA` permitido por la política y ejecuta el entry point. `ForlexOptimizer.cmd` eleva si hace
falta y llama al loader. Detalle en el README.

## Datos generados

- `data/tweaks.json` (también embebido en `src/data/`): generado desde el catálogo de la app de referencia
  + overrides manuales (tweaks premium, planes de energía, importación de `.reg`).
- `src/Resources/regs/*.reg`: recursos usados por los tweaks por lote; el generador parsea cada archivo
  para respaldar exactamente los valores que importa.
- `docs/CATALOG.md`: listado completo con categorías, riesgo y si revierte.

## Build

`build.ps1` corre MSBuild con `tools/roslyn_pkg` como `CscToolPath`, compila XAML + C#, firma el ejecutable
con `tools/sign-file.ps1` y escribe en `dist\`. Los builds se serializan con un mutex global. El proyecto
auxiliar `tools/lead-check/LeadCheck.csproj` compila solo el shell + Core para desarrollo rápido.

## QA

`tools/dev-screenshot.ps1` lanza la app (por el loader), navega a una página (`-Page`) y guarda una captura
en `_shots\<nombre>.png`. El log de la app queda en `%LOCALAPPDATA%\ForlexOptimizer\logs`.
