# Forlex Optimizer

Optimizador completo para Windows 10/11 (64 bits), escrito en **C# + WPF (.NET Framework 4.8)** y empaquetado
como una app nativa portable. Recrea a fondo la funcionalidad de la app de referencia CeitoTweaks
(licencia MIT) con marca propia, catálogo completo de **393 tweaks** en **16 categorías**, backups exactos
del registro y un motor que permite deshacer todo.

![Forlex Optimizer — Inicio](docs/screenshot-dashboard.png)

## Novedades principales

- **393 tweaks** en 16 categorías (Rendimiento FPS, GPU, Red, CPU/RAM, Energía, Windows, Personalización,
  Segundo plano, Privacidad, Almacenamiento, Periféricos, BIOS y drivers, Priorizar juegos, Drivers de mouse,
  Accesos directos, Optimizar apps). Cada uno indica si es **Seguro / Precaución / Riesgoso**.
- **Aplicar y revertir con el mismo botón**. Antes de tocar el registro se guarda el valor exacto que había;
  "Deshacer" lo restaura tal cual (aunque el tweak ya no exista en el catálogo).
- **Optimizar todo**: perfiles Competitivo, Streaming y Notebook, con punto de restauración opcional.
- **Optimizar gráfica**: detección de NVIDIA / AMD / Intel con respaldo y restauración de los ajustes.
- **Planes de energía** propios (Forlex Rendimiento, Notebook Gamer, Silencioso) y control de los de Windows.
- **Modo Juego automático**: detecta la biblioteca de Steam/Epic, aplica el perfil al abrir el juego,
  revierte al cerrarlo y guarda el historial de sesiones.
- **Chequeo de PC**: puntaje de salud, cuello de botella, driver de GPU y problemas accionables.
- **Pruebas**: Hz reales del mouse, CPS, teclado, mando/drift, USB, monitor, reflejos, audio, disco,
  ForlexBench, ping y más.
- **31 arreglos de un clic**, limpieza de disco con SFC/DISM, desinstalador + gestor de inicio y
  12 programas recomendados.
- **Forlex Games**: aim trainer con 7 modos, mira overlay, widget flotante, test de escritura,
  conversor de sensibilidad y filtro de pantalla.
- **Personalización completa**: 5 temas, acento personalizable, fondos, densidad, asistente offline,
  perfil con nivel y logros, exportar/importar configuración.

## Cómo se ejecuta (importante en esta PC)

Esta PC tiene **Smart App Control / WDAC** activo: bloquea ejecutar directamente `.exe` nuevos sin
reputación (incluso firmados con un certificado local). Por eso la app se inicia con un **lanzador** que la
carga en memoria dentro de `powershell.exe` (firmado y permitido):

```
Doble clic en  ForlexOptimizer.cmd
```

- El lanzador pide elevación (UAC) si hace falta y luego abre la app.
- Al compilar, `build.ps1` firma `dist\ForlexOptimizer.exe` con el certificado local de desarrollo
  (el mismo mecanismo de `forlex-launcher`); la firma se mantiene por compatibilidad, aunque la ejecución
  directa puede seguir bloqueada por SAC. El camino soportado es el lanzador.
- En PCs sin Smart App Control, `dist\ForlexOptimizer.exe` funciona también de forma directa
  (requiere admin, como cualquier optimizador que toca servicios y registro de máquina).

## Compilar desde el código

Requisitos: Windows 10/11, .NET Framework 4.8 y MSBuild 4.0 (viene con Windows). El compilador Roslyn
está incluido en `tools/roslyn_pkg` (no hace falta instalar el SDK de .NET).

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
```

- Salida: `dist\ForlexOptimizer.exe` (firmado automáticamente).
- `.\build.ps1 -Run` compila y abre la app con el lanzador.
- `.\build.ps1 -Clean` limpia `obj`, `bin` y `dist`.
- `.\build.ps1 -LeadOnly` compila solo el núcleo + shell en `dist-lead` (para desarrollo del core).
- Los `.ps1` se ejecutan con un PowerShell hijo porque la ExecutionPolicy de esta sesión está restringida.

Capturas de QA (lanza la app, navega a una página y guarda `_shots\<nombre>.png`):

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\tools\dev-screenshot.ps1 -Name tweaks -Page tweaks
```

## Estructura del proyecto

```
forlex-optimizer/
├─ ForlexOptimizer.cmd          Lanzador (eleva y carga la app en memoria)
├─ build.ps1                    Compilación + firma del ejecutable
├─ install.ps1 / uninstall.ps1  Instalación portable con accesos directos
├─ data/tweaks.json             Catálogo generado (393 tweaks, operaciones apply/revert/backups)
├─ src/
│  ├─ Core/                     Catálogo, motor de tweaks, backups, registro, PowerShell, estado, tema, i18n
│  ├─ Controls/                 Gráficos en vivo y anillo de progreso
│  ├─ Styles/                   Tema visual, controles y 1746 iconos vectoriales (Lucide, ISC)
│  ├─ Views/
│  │  ├─ Core/                  Shell + Inicio
│  │  ├─ Tweaks/                Tweaks, Optimizar todo, GPU, Energía, Backups
│  │  ├─ System/                Arreglos, Limpieza, Programas, Inicio/Desinstalador
│  │  ├─ Diagnostics/           Chequeo, Pruebas, Mi sistema
│  │  ├─ Games/                 Modo Juego, Forlex Games (aim, mira, widget, typing, sens, filtro...)
│  │  └─ Custom/                Personalizar, Perfil, Ajustes, Asistente, Acerca de
│  ├─ Services/                 Servicios por dominio
│  ├─ Resources/regs/           Archivos .reg usados por los tweaks por lote
│  ├─ data/tweaks.json          Copia embebida del catálogo
│  └─ i18n/                     Traducciones (es por defecto)
├─ tools/                       Roslyn, firma, lanzador, capturas, generación de catálogo/iconos
└─ docs/                        Arquitectura, licencias, capturas
```

## Seguridad y reversibilidad

- Todo cambio de registro se respalda valor por valor antes de aplicarse; el backup queda en
  `%LOCALAPPDATA%\ForlexOptimizer\backups` y se restaura al revertir.
- Los tweaks por lote (`.reg`) también se respaldan (se parsean sus claves al generar el catálogo).
- Se puede crear un **punto de restauración** de Windows antes de aplicar cambios.
- Los tweaks **Riesgosos** nunca se aplican automáticamente en "Optimizar todo".
- No hay telemetría ni conexiones a servidores propios: todo es local.

## Datos y registros

- Ajustes: `%LOCALAPPDATA%\ForlexOptimizer\settings.json`
- Tweaks aplicados: `%LOCALAPPDATA%\ForlexOptimizer\state.json`
- Backups: `%LOCALAPPDATA%\ForlexOptimizer\backups\*.json`
- Logs: `%LOCALAPPDATA%\ForlexOptimizer\logs\forlex-AAAA-MM-DD.log`

## Licencias y créditos

Proyecto bajo licencia **MIT** (ver `LICENSE`). El catálogo de datos y parte del conocimiento de tweaks se
derivaron de **CeitoTweaks** (MIT) — ver `docs/THIRD_PARTY_NOTICES.md`. Los iconos son **Lucide** (ISC).
Microsoft, NVIDIA, AMD e Intel son marcas de sus respectivos dueños; este proyecto no está afiliado a ellos.
